package app.network;

public enum ResponseType {
    OK,
    ERROR,
    SeatsDecremented,
    NewBookings
}
