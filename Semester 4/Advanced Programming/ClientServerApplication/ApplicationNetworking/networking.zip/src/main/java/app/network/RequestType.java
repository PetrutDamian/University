package app.network;

public enum RequestType {
    LOGIN,
    LOGOUT,
    GETALLCURSE,
    FindByDestinationAndDate,
    GetAllBookings,
    MakeBooking
}
