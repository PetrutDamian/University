package app.repository;

import app.model.User;

public interface IUserRepo extends ICrudRepository<String, User> {
}
